$(document).bind("mobileinit", function(){
	//$.mobile.ajaxEnabled = false;
});